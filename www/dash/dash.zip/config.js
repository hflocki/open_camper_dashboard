/* config.js - Vollständige Camper-Konfiguration */

const WS_HOST = window.location.hostname;
const WS_PORT = 9001;
const WS_PATH = "/";
const MQTT_USERNAME = "mqttcaruser";
const MQTT_PASSWORD = "eUZT2zR9VG4rJ3";
const APP_NAME = "Camper Dashboard";

/* topics.js - Definition aller MQTT Topics */

// --- ESPHome Node Namen ---
const ESPHOME_NODE_HEATER = "smartavan-heater";
const ESPHOME_NODE_FAN = "maxxfan";
const ESPHOME_NODE_GPS = "espgeopos";
const ESPHOME_NODE_TEMP = "esptemp";
const ESPHOME_NODE_WATER = "fuellstand";

// Node ID und Basis-Topic für das Wassersystem
const WATER_MQTT_BASE = "7fc5b1c2-70d0-4fe1-90a5-089e87aa316d/toc/nodes/2726";
const WATER_NODE_SEC = "1712";
const WATER_NODE_ID = "2726";
const MQTT_ROOT_ID = "7fc5b1c2-70d0-4fe1-90a5-089e87aa316d";

// --- Status Topics (LEDs) ---
const HEATER_STATE_TOPIC = `${ESPHOME_NODE_HEATER}/status`;
const ESPGEOPOS_STATE_TOPIC = `${ESPHOME_NODE_GPS}/status`;
const MAXXFAN_STATE_TOPIC = `${ESPHOME_NODE_FAN}/status`;
const ESPTEMP_STATE_TOPIC = `${ESPHOME_NODE_TEMP}/status`;
const WATERLEVEL_STATE_TOPIC = `${ESPHOME_NODE_WATER}/status`;
const CP_PLUS_ALIVE_TOPIC = "truma/alive";
const WLED_STATUS_TOPIC = "wled/f49991/status";

// --- Heizung / Truma ---
const HEATER_SETPOINT_TOPIC = "truma/setpoint_temp";
const HEATER_CURRENT_TOPIC = "truma/current_temp";
const SETPOINT_SET_TOPIC = "truma/set/setpoint_temp";

// --- MaxxFan ---
const MAXXFAN_FAN_STATE_TOPIC = `${ESPHOME_NODE_FAN}/sensor/fan_state/state`;
const MAXXFAN_LID_STATE_TOPIC = `${ESPHOME_NODE_FAN}/sensor/lid_state/state`;
const MAXXFAN_DIRECTION_TOPIC = `${ESPHOME_NODE_FAN}/sensor/fan_direction/state`;
const MAXXFAN_AUTO_STATE_TOPIC = `${ESPHOME_NODE_FAN}/binary_sensor/auto_mode/state`;
const MAXXFAN_CEILING_STATE_TOPIC = `${ESPHOME_NODE_FAN}/binary_sensor/ceiling_fan_mode/state`;

const LID_COMMAND_TOPIC = `${ESPHOME_NODE_FAN}/select/lid_control/command`;
const SPEED_COMMAND_TOPIC = `${ESPHOME_NODE_FAN}/number/fan_speed/command`;

// --- GPS & Neigung ---
const GPS_LAT_TOPIC = `${ESPHOME_NODE_GPS}/sensor/latitude/state`;
const GPS_LON_TOPIC = `${ESPHOME_NODE_GPS}/sensor/longitude/state`;
const GPS_ALT_TOPIC = `${ESPHOME_NODE_GPS}/sensor/altitude/state`;
const GPS_SPEED_TOPIC = `${ESPHOME_NODE_GPS}/sensor/speed/state`;
const GPS_SAT_TOPIC = `${ESPHOME_NODE_GPS}/sensor/satellites/state`;
const GPS_ROLL_TOPIC = `${ESPHOME_NODE_GPS}/sensor/roll_sensor/state`;
const GPS_PITCH_TOPIC = `${ESPHOME_NODE_GPS}/sensor/pitch_sensor/state`;

// --- WasserLevel Direkt-Topics (Wieder aktiviert) ---
const FRESH_WATER_PERCENT_TOPIC = `${WATER_MQTT_BASE}/levelPercent`;
const FRESH_WATER_VOLUME_TOPIC = `${WATER_MQTT_BASE}/levelVolume`;
const FRESH_WATER_ADC_TOPIC = `${WATER_MQTT_BASE}/adc`;

const CALIBRATE_WATER_FULL_TOPIC = `${WATER_MQTT_BASE}/button/wasser_voll_kalibrieren/command`;
const CALIBRATE_WATER_EMPTY_TOPIC = `${WATER_MQTT_BASE}/button/wasser_leer_kalibrieren/command`;

// --- Govee Sensoren ---
const GOVEE_TEMP_TOPIC_1 = "camper/status/govee/A4C1381EA678";
const GOVEE_TEMP_TOPIC_2 = "camper/status/govee/A4C138C2EF51";
const GOVEE_TEMP_TOPIC_3 = "camper/status/govee/880F10857644";

const GEOPOS_TEMP_TOPIC = `${ESPHOME_NODE_GPS}/sensor/temperature/state`;
const GEOPOS_HUM_TOPIC = `${ESPHOME_NODE_GPS}/sensor/humidity/state`;
const GEOPOS_TEMPOUT_TOPIC = `${ESPHOME_NODE_GPS}/sensor/tempout/state`;

// --- Restarts ---
const RESTART_HEATER_TOPIC = `${ESPHOME_NODE_HEATER}/button/restart_switch/command`;
const RESTART_FAN_TOPIC = `${ESPHOME_NODE_FAN}/button/restart_switch/command`;
const RESTART_GPS_TOPIC = `${ESPHOME_NODE_GPS}/button/restart_switch/command`;
const RESTART_TEMP_TOPIC = `${ESPHOME_NODE_TEMP}/button/restart_switch/command`;
const RESTART_WATER_TOPIC = `${ESPHOME_NODE_WATER}/button/restart_switch/command`;

// --- WLED ---
const WLED_BASE = "wled/f49991";
const WLED_BRIGHTNESS_TOPIC = WLED_BASE + "/g";
const WLED_API_TOPIC = WLED_BASE + "/api";
const wledConfig = {
  mqttTopic: WLED_API_TOPIC,
  farben: {
    f1: "FX=0&R=255&G=0&B=0",
    f2: "FX=0&R=0&G=255&B=0",
    f3: "FX=0&R=0&G=0&B=255",
    f4: "FX=0&R=255&G=255&B=255",
  },
};
